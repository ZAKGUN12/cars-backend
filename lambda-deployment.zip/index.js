// Main Lambda handler - uses Cognito authentication
module.exports = require('./cognito-index');